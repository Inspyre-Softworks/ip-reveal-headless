
import PySimpleGUIQt as Qt

class ThemeManager(object):
    def __init__(self):
        """

        A constructor for a more robust theming engine, and understa

        """
        pass

    def apply(self, win):
        """

        Apply your chosen theme to your given window (win)

        Args:
            win: A Qt.window9

        Returns:
             boolean: True = Success | False = Fail (couldn't apply given thj

        """
