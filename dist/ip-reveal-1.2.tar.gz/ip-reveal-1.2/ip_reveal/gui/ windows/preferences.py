import PySimpleGUIQt as psg

from ip_reveal.config import CONF


class Window(object):
    
    active = False
    
    layout = [
            [
                    
                    ]
            ]
