class BackgroundImage(object):
    def __init__(self):
        self.base64 = NEON_DARK

    def change(self):
        pass
