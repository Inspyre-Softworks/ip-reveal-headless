from pathlib import Path

cwd = str(Path(__file__).parent.absolute())

NEON_DARK_FP = cwd + "/neon_dark.png"
